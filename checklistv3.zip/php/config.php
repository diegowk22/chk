<?php 
 
 $con = mysqli_connect("localhost","root","","checklistv2") or die("Nao conectou com o banco de dados.");

?>